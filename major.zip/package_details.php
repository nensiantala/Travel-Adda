<?php
session_start();
if (!isset($_SESSION['customer_id'])) {
    header("Location: customer_login.php");
    exit();
}

include 'db_connect.php';
include 'header.php';

if (!isset($_GET['id'])) {
    header("Location: packages.php");
    exit();
}

$package_id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM packages WHERE id = ? AND status = 'active'");
$stmt->bind_param("i", $package_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<div class='container mt-5 text-center'><h4 class='text-danger'>Package not found or is not available.</h4></div>";
    include 'footer.php';
    exit();
}

$package = $result->fetch_assoc();

// Average rating
$avgStmt = $conn->prepare("SELECT AVG(rating) as avg_rating FROM feedback WHERE package_id = ?");
$avgStmt->bind_param("i", $package_id);
$avgStmt->execute();
$avgResult = $avgStmt->get_result();
$avgRating = round($avgResult->fetch_assoc()['avg_rating'], 1);

$limit = 5; // feedbacks per page
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

?>

<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($package['title']) ?> - Travel Adda</title>
    <!-- <link rel="stylesheet" href="style/style.css"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Nunito Sans', sans-serif;
            background-color: #f7f7f7;
        }

        .details-box {
            background: #fff;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 10px 20px rgba(0,0,0,0.08);
        }

        .carousel-inner img {
            height: 400px;
            object-fit: cover;
        }

        .btn-success {
            background-color: #17B978;
            border: none;
        }

        .btn-success:hover {
            background-color: #14a76c;
        }

        .itinerary-tab {
            background: #fff;
            border-radius: 10px;
            padding: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.06);
            margin-bottom: 5px;
        }

        .day-title {
            font-weight: bold;
            font-size: 1rem;
            color: #00435a;
        }

        .desc-box {
            max-height: 120px;
            overflow: hidden;
            position: relative;
        }

        .desc-box.expanded {
            max-height: none;
        }

        .show-more {
            color: #17B978;
            cursor: pointer;
            font-weight: 500;
            margin-top: 5px;
            display: inline-block;
        }

        .star {
            font-size: 2rem;
            color: #ccc;
            cursor: pointer;
            transition: color 0.3s;
        }

        .star.selected {
            color: gold;
        }

        .comment-wrapper {
            position: relative;
        }

        .full-comment {
            display: none;
        }

        .toggle-comment {
            color: #17B978;
            font-weight: 500;
            cursor: pointer;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <h2 class="mb-4 text-center"><?= htmlspecialchars($package['title']) ?></h2>

    <!-- <div class="container-fluid"> -->
        <div class="col-md-6">
            <!-- Image Carousel -->
            <div id="carousel<?= $package['id'] ?>" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <?php
                    $hasImage = false;
                    for ($i = 1; $i <= 4; $i++) {
                        if (!empty($package["image$i"])) {
                            $hasImage = true;
                            echo '<div class="carousel-item ' . ($i == 1 ? 'active' : '') . '">
                                    <img src="assets/' . htmlspecialchars($package["image$i"]) . '" class="d-block w-100" alt="Package Image">
                                  </div>';
                        }
                    }
                    if (!$hasImage) {
                        echo '<div class="carousel-item active">
                                <img src="assets/default.jpg" class="d-block w-100" alt="Default Image">
                              </div>';
                    }
                    ?>
                </div>
                <?php if ($hasImage): ?>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carousel<?= $package['id'] ?>" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carousel<?= $package['id'] ?>" data-bs-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <div class="col-md-6">
            <div class="details-box">
                <h4>Description</h4>
                <div class="desc-box" id="descBox"><?= nl2br(htmlspecialchars($package['description'])) ?></div>
                <?php if (strlen($package['description']) > 300): ?>
                    <span class="show-more" onclick="toggleDescription()">Show more</span>
                <?php endif; ?>

                <h5 class="mt-3">Duration: <?= htmlspecialchars($package['duration']) ?></h5>
                <h5>Price: ₹<?= htmlspecialchars($package['price']) ?></h5>
                <h5>Trip Dates: <?= date("d M Y", strtotime($package['start_date'])) ?> to <?= date("d M Y", strtotime($package['end_date'])) ?></h5>

                <h4 class="mt-5">Things To Do (Day-wise Itinerary)</h4>
                <?php
                if (!empty($package['itinerary'])) {
                    $days = explode("\n", $package['itinerary']);
                    foreach ($days as $day) {
                        $parts = explode("|", trim($day));
                        if (count($parts) == 3) {
                            echo '<div class="itinerary-tab">
                                    <div class="day-title">' . htmlspecialchars($parts[0]) . ' — ' . htmlspecialchars($parts[1]) . '</div>
                                    <div class="text-muted">Duration: ' . htmlspecialchars($parts[2]) . '</div>
                                  </div>';
                        }
                    }
                } else {
                    echo "<p class='text-muted'>Itinerary not available.</p>";
                }
                ?>

                <a href="book.php?package_id=<?= $package['id'] ?>" class="btn btn-success btn-lg mt-4 w-100">Book Now</a>
                <a href="packages.php" class="btn btn-secondary mt-2 w-100">Back to Packages</a>
    </div> 
    <!-- </div>            -->
                <!-- Feedback Section -->
                <h5 class="mt-5">Feedback for this Package</h5>
                <p><strong>Average Rating:</strong> <?= $avgRating ? $avgRating . " / 5" : "No ratings yet" ?></p>

                <form id="feedbackForm">
                    <input type="hidden" name="package_id" value="<?= $package_id ?>">
                    <label><strong>Rate this package:</strong></label><br>
                    <div id="star-container" class="mb-2">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <span class="star" data-value="<?= $i ?>">&#9734;</span>
                        <?php endfor; ?>
                    </div>
                    <input type="hidden" name="rating" id="ratingInput" value="0" required>

                    <div class="mb-3">
                        <label for="comment"><strong>Comment:</strong></label>
                        <textarea name="comment" class="form-control" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit Feedback</button>
                </form>

                <!-- All Feedback Display -->

                
                <div id="feedbackDisplay" class="mt-4">
                    <?php
                    $feedStmt = $conn->prepare("
                    SELECT f.rating, f.comment, c.username, f.created_at 
                    FROM feedback f 
                    JOIN customers c ON f.customer_id = c.id 
                    WHERE f.package_id = ? AND f.status = 'approved' 
                    ORDER BY f.created_at DESC 
                    LIMIT ? OFFSET ?
                 ");

            $feedStmt->bind_param("iii", $package_id, $limit, $offset); // ✅ 3 parameters bound
                    $feedStmt->execute();
                    $feedbacks = $feedStmt->get_result();

                    while ($fb = $feedbacks->fetch_assoc()):
                        $comment = htmlspecialchars($fb['comment']);
                        $short = substr($comment, 0, 200);
                        $isLong = strlen($comment) > 200;
                    ?>
                    <div class="border rounded p-3 mb-3 bg-light">
                        <strong><?= htmlspecialchars($fb['username']) ?></strong> rated: <?= $fb['rating'] ?>/5<br>
                        <small class="text-muted"><?= $fb['created_at'] ?></small>
                        <div class="comment-wrapper">
                            <div class="short-comment"><?= nl2br($short) ?><?= $isLong ? '...' : '' ?></div>
                            <?php if ($isLong): ?>
                                <div class="full-comment"><?= nl2br($comment) ?></div>
                                <div class="toggle-comment" onclick="toggleComment(this)">Show more</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endwhile; ?>
                    <?php
// Get total approved feedback count
$countStmt = $conn->prepare("SELECT COUNT(*) as total FROM feedback WHERE package_id = ? AND status = 'approved'");
$countStmt->bind_param("i", $package_id);
$countStmt->execute();
$countResult = $countStmt->get_result();
$totalRows = $countResult->fetch_assoc()['total'];
$totalPages = ceil($totalRows / $limit);
?>

    <!-- Pagination UI -->
        <nav class="mt-3">
    <ul class="pagination justify-content-center">
        <?php if ($page > 1): ?>
            <li class="page-item">
                <a class="page-link" href="?id=<?= $package_id ?>&page=<?= $page - 1 ?>">Previous</a>
            </li>
        <?php endif; ?>

        <?php for ($p = 1; $p <= $totalPages; $p++): ?>
            <li class="page-item <?= $p == $page ? 'active' : '' ?>">
                <a class="page-link" href="?id=<?= $package_id ?>&page=<?= $p ?>"><?= $p ?></a>
            </li>
        <?php endfor; ?>

        <?php if ($page < $totalPages): ?>
            <li class="page-item">
                <a class="page-link" href="?id=<?= $package_id ?>&page=<?= $page + 1 ?>">Next</a>
            </li>
        <?php endif; ?>
    </ul>
        </nav>

                </div>
            </div>
        
    
</div>

<script>
function toggleDescription() {
    const box = document.getElementById("descBox");
    box.classList.toggle("expanded");
    document.querySelector(".show-more").textContent =
        box.classList.contains("expanded") ? "Show less" : "Show more";
}

function toggleComment(link) {
    const wrapper = link.closest('.comment-wrapper');
    const full = wrapper.querySelector('.full-comment');
    const short = wrapper.querySelector('.short-comment');

    if (full.style.display === 'none' || full.style.display === '') {
        short.style.display = 'none';
        full.style.display = 'block';
        link.textContent = 'Show less';
    } else {
        short.style.display = 'block';
        full.style.display = 'none';
        link.textContent = 'Show more';
    }
}

document.querySelectorAll('.star').forEach(star => {
    star.addEventListener('click', () => {
        const value = star.getAttribute('data-value');
        document.getElementById('ratingInput').value = value;
        document.querySelectorAll('.star').forEach(s => s.classList.remove('selected'));
        for (let i = 0; i < value; i++) {
            document.querySelectorAll('.star')[i].classList.add('selected');
        }
    });
});

document.getElementById('feedbackForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch('submit_feedback.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.text())
    .then(response => {
        if (response.trim() === 'success') {
            alert("Thanks for your feedback!");
            location.reload();
        } else {
            alert("Failed to submit feedback.");
        }
    });
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php include 'footer.php'; ?>
