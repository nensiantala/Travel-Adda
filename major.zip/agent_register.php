<?php
include 'db_connect.php';

$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $company = trim($_POST['company_name']);
    $employee_count = intval($_POST['employee_count']);

    $check = $conn->prepare("SELECT id FROM agents WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $error = "Email already registered.";
    } else {
        $stmt = $conn->prepare("INSERT INTO agents (email, phone, password, company_name, employee_count) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $email, $phone, $password, $company, $employee_count);

        if ($stmt->execute()) {
            $success = "Registered successfully! You can now log in.";
        } else {
            $error = "Registration failed.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Agent Register - Travel Adda</title>
    <link rel="stylesheet" href="style/logincss.css">
    <style>
        .styled-select {
    width: 100%;
    padding: 12px;
  margin: 10px 0;
  border: 1px solid #ccc;
  border-radius: 8px;
  transition: border-color 0.3s;
    background-color: #fff;
    color:rgb(134, 134, 134);
    font-size: 13px;
    margin-bottom: 15px;
    appearance: none; /* Removes default arrow in some browsers */
    -webkit-appearance: none;
    -moz-appearance: none;
    background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20width%3D'10'%20height%3D'10'%20viewBox%3D'0%200%2010%2010'%20xmlns%3D'http://www.w3.org/2000/svg'%3E%3Cpath%20d%3D'M0%202l5%205%205-5z'%20fill%3D'%2317B978'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    background-size: 12px;
}

.styled-select:focus {
    border-color: #17B978;
    box-shadow: 0 0 0 3px rgba(23, 185, 120, 0.25);
    outline: none;
}

    </style>
</head>
<body>
<div class="container">
    <h2>Agent Registration</h2>
    <?php if ($success) echo "<p class='success'>$success</p>"; ?>
    <?php if ($error) echo "<p class='error'>$error</p>"; ?>
    <form method="POST">
        <input type="email" name="email" placeholder="Email (Gmail)" required><br>
        <input type="text" name="phone" placeholder="Phone Number" required><br>
        <input type="password" name="password" placeholder="Password" required><br>
        <input type="text" name="company_name" placeholder="Company Name" required><br>
        <select name="employee_count" required class="styled-select">
            <option value="">Select Employee Count</option>
            <option value="1">1-10</option>
            <option value="2">11-50</option>
            <option value="3">51-100</option>
            <option value="4">100+</option>
        </select><br>
        <button type="submit">Register</button>
    </form>
    <p>Already an agent? <a href="agent_login.php">Login here</a></p>
</div>
</body>
</html>
