<?php
session_start();
include 'db_connect.php';

$result = $conn->query("SELECT * FROM packages");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Travel Adda</title>
  <link rel="stylesheet" href="styles.css">
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand d-flex align-items-center" href="index.php">
            <img src="image/logo.png" alt="Travel Adda Logo" height="40" class="me-2">
            <span class="fw-bold text-white">Travel Adda</span>
        </a>
    <div class="navbar-nav ms-auto">
      <?php if (!isset($_SESSION['user'])): ?>
        <a class="nav-item nav-link" href="customer_login.php">Login Now</a>
      <?php else: ?>
        <a class="nav-item nav-link" href="logout.php">Logout</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<!-- Page Content -->
<div class="container mt-4">
  <h2 class="text-center mb-4">Welcome to Travel Adda</h2>

<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="image/montain.jpg" alt="First slide">
      <div class="carousel-caption d-none d-md-block">
  <h2 class="fw-bold text-shadow">Discover Your Next Adventure</h2>
  <p class="lead text-shadow">Explore breathtaking destinations with Travel Adda.</p>
</div>

    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="image/stary.jpg" alt="Second slide">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="image/camp.jpg" alt="Third slide">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
  <div class="row justify-content-center">
    <?php while($row = $result->fetch_assoc()): ?>
      <div class="card" style="width: 18rem; margin: 10px;">
<div id="carousel<?= $row['id'] ?>" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <?php for ($i = 1; $i <= 4; $i++): ?>
      <?php if (!empty($row["image$i"])): ?>
        <div class="carousel-item <?= $i == 1 ? 'active' : '' ?>">
          <img src="assets/<?= htmlspecialchars($row["image$i"]); ?>" class="d-block w-100" height="200px" alt="Image <?= $i ?>">
        </div>
      <?php endif; ?>
    <?php endfor; ?>
  </div>
  <a class="carousel-control-prev" href="#carousel<?= $row['id'] ?>" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carousel<?= $row['id'] ?>" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
        <div class="card-body">
          <h5 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h5>
          <p class="card-text"><?php echo htmlspecialchars($row['description']); ?></p>
          <p><strong><?php echo htmlspecialchars($row['duration']); ?> | ₹<?php echo htmlspecialchars($row['price']); ?></strong></p>
          <?php if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'customer'): ?>
            <a href="customer_login.php" class="btn btn-primary">Login to Book</a>
          <?php else: ?>
            <a href="book.php?package_id=<?php echo $row['id']; ?>" class="btn btn-success">Book Now</a>
          <?php endif; ?>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
   <!-- Feedback Section -->
    <h3 class="text-center mt-5">What Customers Are Saying</h3>
    <div class="row mt-4">
        <?php
        $feedbackQuery = "SELECT f.*, c.username, p.title AS package_title
                          FROM feedback f
                          JOIN customers c ON f.customer_id = c.id
                          JOIN packages p ON f.package_id = p.id
                          WHERE f.status = 'approved'
                          ORDER BY f.created_at DESC";
        $feedbackResult = $conn->query($feedbackQuery);

        if ($feedbackResult && $feedbackResult->num_rows > 0):
            while ($fb = $feedbackResult->fetch_assoc()):
        ?>
            <div class="col-md-6 mb-4">
                <div class="review-card h-100">
                    <h6><?= htmlspecialchars($fb['username']) ?></h6>
                    <div class="package-name">Package: <?= htmlspecialchars($fb['package_title']) ?></div>
                    <div class="stars"><?= str_repeat("★", $fb['rating']) . str_repeat("☆", 5 - $fb['rating']) ?></div>
                    <?php
                      $comment = htmlspecialchars($fb['comment']);
                      $short = mb_substr($comment, 0, 100);
                      $isLong = mb_strlen($comment) > 100;
                      ?>

                      <p class="comment">
                          <span class="short-comment"><?= nl2br($short) ?><?= $isLong ? '...' : '' ?></span>
                              <?php if ($isLong): ?>
                              <span class="full-comment d-none"><?= nl2br($comment) ?></span>
                                <a href="javascript:void(0);" class="toggle-comment text-primary" onclick="toggleComment(this)">Show more</a>
                                <?php endif; ?>
                      </p>

                    <div class="date">Reviewed on <?= date("d M Y, h:i A", strtotime($fb['created_at'])) ?></div>
                </div>
            </div>
        <?php endwhile; else: ?>
            <div class="col-12 text-center">
                <p class="text-muted">No reviews yet. Be the first to leave one!</p>
            </div>
        <?php endif; ?>
    </div>
        </div>
<script>
function toggleComment(link) {
    const commentBox = link.closest('.comment');
    const shortText = commentBox.querySelector('.short-comment');
    const fullText = commentBox.querySelector('.full-comment');

    if (fullText.classList.contains('d-none')) {
        shortText.style.display = 'none';
        fullText.classList.remove('d-none');
        link.textContent = 'Show less';
    } else {
        shortText.style.display = 'inline';
        fullText.classList.add('d-none');
        link.textContent = 'Show more';
    }
}
</script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php include "footer.php"; ?>
