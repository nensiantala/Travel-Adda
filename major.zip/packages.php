<?php
session_start();
if (!isset($_SESSION['customer_id'])) {
    header("Location: customer_login.php");
    exit();
}

include 'db_connect.php';
include 'header.php';

// Fetch all active packages
$sql = "SELECT * FROM packages WHERE status = 'active'";
$result = $conn->query($sql);

$customer_name = $_SESSION['customer_username'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Travel Packages - Travel Adda</title>
    <link rel="stylesheet" href="style/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .card:hover {
            transform: scale(1.02);
            transition: transform 0.3s;
        }
        .carousel-inner img {
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-4 text-center">All Available Travel Packages</h2>

    <div class="row">
        <?php if ($result->num_rows > 0): ?>
            <?php while($package = $result->fetch_assoc()): ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <!-- Carousel Start -->
                        <div id="carousel<?= $package['id'] ?>" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php for ($i = 1; $i <= 4; $i++): ?>
                                    <?php if (!empty($package["image$i"])): ?>
                                        <div class="carousel-item <?= $i == 1 ? 'active' : '' ?>">
                                            <img src="assets/<?= htmlspecialchars($package["image$i"]); ?>" class="d-block w-100" alt="Image <?= $i ?>">
                                        </div>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carousel<?= $package['id'] ?>" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon"></span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carousel<?= $package['id'] ?>" data-bs-slide="next">
                                <span class="carousel-control-next-icon"></span>
                            </button>
                        </div>
                        <!-- Carousel End -->

                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($package['title']); ?></h5>
                            <p class="card-text"><?= htmlspecialchars($package['description']); ?></p>
                            <p><strong><?= htmlspecialchars($package['duration']); ?> | ₹<?= htmlspecialchars($package['price']); ?></strong></p>
                            <a href="book.php?package_id=<?= $package['id']; ?>" class="btn btn-success w-100">Book Now</a>
                            <a href="package_details.php?id=<?= $package['id'] ?>" class="btn btn-primary w-100 mt-2">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center">
                <p class="text-danger">No packages available at the moment. Please check back later!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php include "footer.php"; ?>
